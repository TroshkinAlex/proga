package models;

/**
 * enum with colors
 */
public enum Color {
    BLACK,
    BLUE,
    ORANGE;
}