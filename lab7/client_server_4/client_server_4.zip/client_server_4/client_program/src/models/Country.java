package models;

/**
 * enum with countries
 */
public enum Country {
    FRANCE,
    SPAIN,
    CHINA,
    NORTH_KOREA,
    JAPAN;
}