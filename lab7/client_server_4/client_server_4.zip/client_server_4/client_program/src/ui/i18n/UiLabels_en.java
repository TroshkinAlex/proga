package ui.i18n;

import java.util.ListResourceBundle;

public class UiLabels_en extends ListResourceBundle {

    public Object[][] getContents() { return contents; }
    private Object[][] contents = {
        {"tab_login", "Login"},
        {"tab_register", "I'm new user"},
        {"field_login", "Login"},
        {"field_password", "Password"}
    };

}
